//
//  ViewController.m
//  curr
//
//  Created by Angela on 2020-04-13.
//  Copyright © 2020 angela. All rights reserved.
//

#import "ViewController.h"
#import "CurrencyRequest/CRCurrencyRequest.h"
#import "CurrencyRequest/CRCurrencyResults.h"

@interface ViewController () <CRCurrencyRequestDelegate>

@property (nonatomic) CRCurrencyRequest * req;
@property (weak, nonatomic) IBOutlet UITextField *input;
@property (weak, nonatomic) IBOutlet UIButton *convert;

@property (weak, nonatomic) IBOutlet UILabel *cua;
@property (weak, nonatomic) IBOutlet UILabel *cub;
@property (weak, nonatomic) IBOutlet UILabel *cuc;

@end

@implementation ViewController
- (IBAction)button:(id)sender {
    
    self.convert.enabled = NO;
    
    self.req = [[CRCurrencyRequest alloc] init];
    self.req.delegate = self; // result is ours
    
    [self.req start];
    
}
                       // mandatory function
- (void)currencyRequest:(CRCurrencyRequest *)req
    retrievedCurrencies:(CRCurrencyResults *)currencies{
    
    self.convert.enabled = YES;
    
    double inputv = [self.input.text floatValue];
    
    
    double eurov = inputv * currencies.EUR;
    NSString *tempe = [NSString stringWithFormat:@"%.2f", eurov];
    self.cua.text = tempe;
    
    double yenv = inputv * currencies.JPY;
    NSString *tempj = [NSString stringWithFormat:@"%.2f", yenv];
    self.cub.text = tempj;
    
    double mv = inputv * currencies.MXN;
    NSString *tempp = [NSString stringWithFormat:@"%.2f", mv];
    self.cuc.text = tempp;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
