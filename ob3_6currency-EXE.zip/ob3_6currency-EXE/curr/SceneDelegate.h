//
//  SceneDelegate.h
//  curr
//
//  Created by Angela on 2020-04-13.
//  Copyright © 2020 angela. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

